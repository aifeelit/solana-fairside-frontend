import React from 'react';

const Dashboard = () => {
  
  return (
    <>
      <div className="d-flex align-items-center justify-content-center flex-column text-center">
        <h1>Dashboard</h1>
        <p>
          This is dashboard
        </p>
      </div>
    </>
  );
}

export default Dashboard;

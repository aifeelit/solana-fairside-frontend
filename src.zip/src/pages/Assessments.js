import React from 'react';

const Assessments = () => {
  
  return (
    <>
      <div className="d-flex align-items-center justify-content-center flex-column text-center">
        <h1>Assessments</h1>
        <p>
          This is the assessments
        </p>
      </div>
    </>
  );
}

export default Assessments;

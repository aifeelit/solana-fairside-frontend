import React from 'react';

const Manage = () => {
  
  return (
    <>
      <div className="d-flex align-items-center justify-content-center flex-column text-center">
        <h1>Manage</h1>
        <p>
          This is the manage
        </p>
      </div>
    </>
  );
}

export default Manage;
